//save a reservation
let booking = document.getElementById("Book");
booking.addEventListener("click", function(e) {

  let days = document.getElementById("days");
  let hours = document.getElementById("houres");
  let fName = document.getElementById("fName");
  let pNum = document.getElementById("pNum");
  let people = document.getElementById("people");

  
    if (days.value == "" || hours.value == "") {
        return alert("Please Enter Your Name and Email")
    }

  let bookedBy = localStorage.getItem("bookedBy");
  if (bookedBy == null) {
    reservation = [];
  } else {
    reservation = JSON.parse(bookedBy);
  }
  let customer = {
    days: days.value,
    hours: hours.value,
    name:fName.value,
    num:pNum.value,
    people:people.value
  }
  reservation.push(customer);
  localStorage.setItem("bookedBy", JSON.stringify(reservation));
  alert("Your Reservation is Done")
  days.value = "";
  hours.value = "";
  fName.value = "";
  pNum.value = "";
  people.value = "";
  console.log(reservation);
  showData();
  let url = "viewbooked.html";
  window.location.assign(url);
  return false;
}); 